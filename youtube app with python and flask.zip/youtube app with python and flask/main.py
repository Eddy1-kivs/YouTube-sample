from flask import Flask, jsonify, render_template
import pprint
import requests
from numerize.numerize import numerize

CHANNELS = {
	'cleverprogrammer': 'UCqrILQNl5Ed9Dz6CGMyvMTQ',
	'mrbeast': 'UCX60Q3DkcsbYNE6H8uQQuVA',
	'eddy': 'UCJ5v_MCY6GNUBTO8-D3XoAg',
	'mkbhd': 'UCBJycsmduvYEL83R_U4JriQ',
	'pm': 'UC3DkFux8Iv-aYnTRWzwaiBA',
}

ACTIVE_CHANNEL = CHANNELS['mkbhd']
# pp = pprint.PrettyPrinter(indent=1)

app = Flask(__name__)


@app.route('/')
def index():
	url = "https://youtube138.p.rapidapi.com/channel/videos/"
	querystring = {"id": ACTIVE_CHANNEL, "hl": "en", "gl": "US"}

	headers = {
		"X-RapidAPI-Key": "f6f2708152msh6aa4725232596bbp19862fjsnd071861b9382",
		"X-RapidAPI-Host": "youtube138.p.rapidapi.com"
	}

	response = requests.request("GET", url, headers=headers, params=querystring)
	data = response.json()
	contents = data['contents']
	videos = [video['video'] for video in contents if video['video']['publishedTimeText']]
	print(videos)
	video = videos[0]
	return render_template('index.html', videos=videos, video=video)
@app.template_filter()
def numberize(views):
	return numerize(views, 1)

@app.template_filter()
def highest_quality_image(images):
	return images[3]['url'] if len(images) >= 4 else images[0]['url']

app.run(host='127.0.0.1', port=8080, debug=True)



